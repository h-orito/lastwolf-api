update SKILL set skill_short_name = '呪' where skill_code = 'CURSEWOLF';
update SKILL set skill_short_name = '智' where skill_code = 'WISEWOLF';
