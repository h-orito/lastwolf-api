insert into MESSAGE_TYPE values ('PRIVATE_WISE', '役職占い結果');
insert into MESSAGE_TYPE values ('PRIVATE_GURU', '役職霊視結果');
insert into MESSAGE_TYPE values ('PRIVATE_FANATIC', '狂信者人狼確認メッセージ');
insert into MESSAGE_TYPE values ('PRIVATE_CORONER', '検死結果');
insert into MESSAGE_TYPE values ('SYMPATHIZE_SAY', '共鳴発言');
delete from MESSAGE_TYPE where message_type_code = 'MASON_SAY';